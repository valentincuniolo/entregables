import * as readlineSync from 'readline-sync';


export
function lanzarDado():number{
    return Math.floor(Math.random() * 12) + 1;
}



