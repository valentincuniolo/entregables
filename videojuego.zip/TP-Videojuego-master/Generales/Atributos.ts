export interface Atributos{
         nombre:string;
         nivel:number;
         inteligencia:number;
         Vida:number;
         Aguante:number;
         agilidad:number;
         fuerza:number;
         destreza:number;
         constitucion:number;
         habilidades:string[];
         tipo:string;
}